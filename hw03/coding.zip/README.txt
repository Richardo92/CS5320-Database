Name: Siyu Zhu(sz432) Wen Fan(wf85) Zhidong Liu(zl479)
Note: I implemented intersect funciton and containSubset funciton in Class AttributeSet to ber helper methods.


