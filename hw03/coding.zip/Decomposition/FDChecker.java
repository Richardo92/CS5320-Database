import java.util.*;

public class FDChecker {

	/**
	 * Checks whether a decomposition of a table is dependency
	 * preserving under the set of functional dependencies fds
	 * 
	 * @param t1 one of the two tables of the decomposition
	 * @param t2 the second table of the decomposition
	 * @param fds a complete set of functional dependencies that apply to the data
	 * 
	 * @return true if the decomposition is dependency preserving, false otherwise
	 **/
	public static boolean checkDepPres(AttributeSet t1, AttributeSet t2, Set<FunctionalDependency> fds) {
		//your code here
		//a decomposition is dependency preserving, if local functional dependencies are
		//sufficient to enforce the global properties
		//To check a particular functional dependency a -> b is preserved, 
		//you can run the following algorithm
		//result = a
		//while result has not stabilized
		//	for each table in the decomposition
		//		t = result intersect table 
		//		t = closure(t) intersect table
		//		result = result union t
		//if b is contained in result, the dependency is preserved
		AttributeSet table[] = {t1, t2};
		for (FunctionalDependency  d: fds){
			AttributeSet a = d.left;
			Attribute b = d.right;
			AttributeSet oldA = new AttributeSet();
			//while result has not stabilized
			while (!oldA.equals(a)){
				oldA = new AttributeSet(a);
				for (AttributeSet t: table){
					AttributeSet temp = a.intersect(t);
					temp = closure(temp,fds).intersect(t);
					a.addAll(temp);
				}	
			}
			if (!a.contains(b))
				return false;
		}
		return true;
	}

	/**
	 * Checks whether a decomposition of a table is lossless
	 * under the set of functional dependencies fds
	 * 
	 * @param t1 one of the two tables of the decomposition
	 * @param t2 the second table of the decomposition
	 * @param fds a complete set of functional dependencies that apply to the data
	 * 
	 * @return true if the decomposition is lossless, false otherwise
	 **/
	public static boolean checkLossless(AttributeSet t1, AttributeSet t2, Set<FunctionalDependency> fds) {
		//your code here
		//Lossless decompositions do not lose information, the natural join is equal to the 
		//original table.
		//a decomposition is lossless if the common attributes for a superkey for one of the
		//tables.
		AttributeSet intersection =  t1.intersect(t2);
		AttributeSet xNy = closure(intersection, fds);
		if (xNy.containSubset(t1) || xNy.containSubset(t2))
			return true;
		return false;
	}

	//recommended helper method
	//finds the total set of attributes implied by attrs
	public static AttributeSet closure(AttributeSet attrs, Set<FunctionalDependency> fds) {
		AttributeSet closure = attrs;
		AttributeSet oldClosure = new AttributeSet();
		// until no change 
		while (!closure.equals(oldClosure)){
			oldClosure = new AttributeSet(closure);
			for (FunctionalDependency fd: fds){
				// if there is a U->V in F that U in closure, add V to closure 
				if (closure.containSubset(fd.left)){
					closure.add(fd.right);
					//break;
				}
			}	
		}
		return closure;
	}
}
