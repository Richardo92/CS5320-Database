import java.util.*;

public class AttributeSet extends HashSet<Attribute> {

	public AttributeSet() {
		super();
	}

	public AttributeSet(AttributeSet other) {
		super(other);
	}
	
	public AttributeSet intersect(AttributeSet a){
		AttributeSet temp = new AttributeSet(this);
		temp.retainAll(a);
		return temp;		
	}
	
	public boolean containSubset(AttributeSet sub){
		for (Attribute iter: sub){
			if  (!this.contains(iter)) 
				return false;
		}
		return true;
	}
	
}